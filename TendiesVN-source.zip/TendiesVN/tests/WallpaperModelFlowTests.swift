// Controlled worker responses; does not open apps or access a real device.
import SwiftUI
import Foundation

struct WallpaperDescriptorStub {}
struct TendiesPayload { var descriptors = [WallpaperDescriptorStub()] }
struct WallpaperStagedPackage: Identifiable { let id = UUID(); var displayName = "Fixture"; var payload = TendiesPayload() }
enum WallpaperInstallStatus { case installed, preparing, restored }
struct WallpaperInstallReceipt: Identifiable { let id = UUID(); var status = WallpaperInstallStatus.installed }
struct WallpaperAccessReport { var canInstall = true }
struct WallpaperOperationStatus: Identifiable {
    enum Kind { case working, success, failure }
    let id: UUID
    var kind: Kind
    var title: String
    var detail: String
    var phases: [String]
    var activePhase: Int?
    init(id: UUID = UUID(), kind: Kind, title: String, detail: String, phases: [String] = [], activePhase: Int? = nil) {
        self.id=id; self.kind=kind; self.title=title; self.detail=detail; self.phases=phases; self.activePhase=activePhase
    }
}
enum DeviceCompatibility {
    static var installationSupported = true
    static let explanation = "Unavailable fixture OS"
}
enum FixtureFailure: Error { case rejected }
enum Fixture {
    static var failInstall = false
    static var failRestore = false
    static var launchSucceeds = true
    static var launches = 0
    static var writes = 0
    static var records: [WallpaperInstallReceipt] = []
}
enum WallpaperPackageStore {
    static func packages() -> [WallpaperStagedPackage] { [] }
    static func importPackage(from: URL) throws -> WallpaperStagedPackage { WallpaperStagedPackage() }
    static func delete(_: WallpaperStagedPackage) throws {}
}
enum WallpaperDeviceAccessService {
    static func report() throws -> WallpaperAccessReport { WallpaperAccessReport() }
    static func receipts() -> [WallpaperInstallReceipt] { Fixture.records }
    static func install(_: WallpaperStagedPackage) throws -> WallpaperAccessReport {
        if Fixture.failInstall { throw FixtureFailure.rejected }
        Fixture.writes += 1
        let receipt = WallpaperInstallReceipt()
        Fixture.records = [receipt]
        return WallpaperAccessReport()
    }
    static func restore(receipt: WallpaperInstallReceipt) throws -> WallpaperAccessReport {
        if Fixture.failRestore { throw FixtureFailure.rejected }
        Fixture.records = []
        return WallpaperAccessReport()
    }
}
func TendiesOpenPosterBoard() -> Bool { Fixture.launches += 1; return Fixture.launchSucceeds }

@main
struct WallpaperModelFlowTests {
    @MainActor
    static func settled(_ model: WallpaperModel) async {
        let deadline = Date().addingTimeInterval(10)
        while model.isBusy {
            precondition(Date() < deadline, "Worker timed out")
            await Task.yield()
        }
    }

    @MainActor
    static func main() async {
        let model = WallpaperModel()
        let package = WallpaperStagedPackage()
        model.selectedPackage = package
        // Committed install must wait for dismissal and launch exactly once.
        model.install(package)
        await settled(model)
        precondition(model.successNotice?.kind == .success && Fixture.writes == 1)
        precondition(model.selectedPackage == nil && Fixture.launches == 0)
        model.sheetDismissed()
        model.sheetDismissed()
        precondition(Fixture.launches == 1 && model.message == nil)
        model.sceneBecameActive()
        precondition(model.message != nil)
        model.message = nil
        model.sceneBecameActive()
        precondition(model.message == nil)
        // Failed writes never open PosterBoard or leave old completion state.
        Fixture.failInstall = true
        model.install(package)
        await settled(model)
        model.sheetDismissed()
        model.openPosterBoardForRefresh()
        precondition(model.successNotice?.kind == .failure && Fixture.launches == 1)
        precondition(model.refreshInstructions == nil)
        // A rejected launch must preserve the successful filesystem outcome.
        Fixture.failInstall = false
        Fixture.launchSucceeds = false
        model.install(package)
        await settled(model)
        model.sheetDismissed()
        precondition(Fixture.launches == 2 && model.successNotice?.kind == .success)
        precondition(model.message != nil && model.activeReceipts.count == 1)
        model.message = nil
        model.sceneBecameActive()
        precondition(model.message == nil)
        // Restore launches after success; failure retains a recoverable receipt.
        let receipt = model.activeReceipts[0]
        Fixture.failRestore = true
        model.restore(receipt)
        await settled(model)
        precondition(Fixture.launches == 2 && model.activeReceipts.count == 1)
        Fixture.failRestore = false
        model.restore(receipt)
        await settled(model)
        precondition(Fixture.launches == 3 && model.activeReceipts.isEmpty)
        // Unsupported versions cannot invoke the worker or the launcher.
        DeviceCompatibility.installationSupported = false
        let writes = Fixture.writes
        model.install(package)
        model.sheetDismissed()
        model.openPosterBoardForRefresh()
        precondition(Fixture.writes == writes && Fixture.launches == 3)
        precondition(model.successNotice?.kind == .failure)
        print("Model flow: post-dismiss launch, foreground notice, failed writes, rejected launch, restore and OS gate passed with mocks.")
    }
}
