#!/usr/bin/env python3
"""Exercise actual descriptor transactions only in temporary macOS directories."""
from pathlib import Path
import shutil
import platform
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class WallpaperInstallerTests(unittest.TestCase):
    @unittest.skipUnless(sys.platform == "darwin" and shutil.which("swiftc"), "requires macOS Foundation/Darwin and Swift")
    def test_commit_rollback_and_recovery_preserve_original_data(self):
        with tempfile.TemporaryDirectory(prefix="1809-installer-build-") as directory:
            binary = Path(directory) / "installer-tests"
            subprocess.run([
                shutil.which("swiftc"), "-swift-version", "5",
                "-target", platform.machine() + "-apple-macosx13.0",
                str(ROOT / "TendiesVN/Engine/WallpaperLabModels.swift"),
                str(ROOT / "TendiesVN/Engine/WallpaperInstaller.swift"),
                str(ROOT / "tests/WallpaperInstallerTests.swift"), "-o", str(binary),
            ], check=True, timeout=120)
            subprocess.run([str(binary)], check=True, timeout=30)


if __name__ == "__main__":
    unittest.main()
