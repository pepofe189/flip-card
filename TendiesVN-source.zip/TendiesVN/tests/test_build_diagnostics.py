#!/usr/bin/env python3
"""Check failed-build reporting and exit codes without pretending to run Xcode."""

import importlib.util
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import textwrap
import unittest


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("build_diagnostics", ROOT / "scripts/summarize-build-log.py")
DIAGNOSTICS = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(DIAGNOSTICS)


class BuildDiagnosticsTests(unittest.TestCase):
    def test_swift_error_and_source_context_are_visible(self):
        log = "Compiling Guide.swift\nGuide.swift:26:15: error: extra trailing closure passed in call\n26 | } footer: {\n   |   ^\nBUILD FAILED\n"
        summary = DIAGNOSTICS.summarize(log)
        self.assertIn("Guide.swift:26:15: error:", summary)
        self.assertIn("} footer:", summary)
        self.assertIn("build/xcodebuild.log", summary)

    def test_fatal_header_error_is_not_replaced_with_exit_code(self):
        log = "In file included from Bridge.h:3:\nHeader.h:8:10: fatal error: 'missing.h' file not found\n#include <missing.h>\n3 failures\n"
        summary = DIAGNOSTICS.summarize(log)
        self.assertIn("fatal error: 'missing.h'", summary)
        self.assertIn("#include <missing.h>", summary)

    def test_duplicate_errors_are_bounded_and_terminal_color_is_removed(self):
        first = "One.swift:1:1: error: first"
        log = "\n".join(["\x1b[31m" + first + "\x1b[0m", "line", "line", first,
                          "line", "line", "Two.swift:2:1: error: second", "line", "line",
                          "Three.swift:3:1: error: third"])
        summary = DIAGNOSTICS.summarize(log, maximum_errors=2)
        self.assertEqual(summary.count(first), 1)
        self.assertIn("error: second", summary)
        self.assertNotIn("error: third", summary)
        self.assertNotIn("\x1b", summary)

    def test_fallback_reports_missing_diagnostic_without_inventing_a_cause(self):
        summary = DIAGNOSTICS.summarize("Process terminated\nexit 65\n")
        self.assertIn("No compiler error line was found", summary)
        self.assertIn("exit 65", summary)

    def run_fixture(self, xcode_version):
        with tempfile.TemporaryDirectory(prefix="1809-build-test-") as temp:
            project = Path(temp) / "project with spaces"
            scripts = project / "scripts"
            scripts.mkdir(parents=True)
            for name in ["build-unsigned.sh", "summarize-build-log.py"]:
                shutil.copy2(ROOT / "scripts" / name, scripts / name)
            (scripts / "prepare-idevice.py").write_text("print('fixture dependency prepared')\n")
            binaries = Path(temp) / "bin"
            binaries.mkdir()
            commands = {
                "uname": "#!/bin/sh\nprintf 'Darwin\\n'\n",
                "xcrun": "#!/bin/sh\nexit 0\n",
                "xcodebuild": textwrap.dedent(f"""\
                    #!{sys.executable}
                    import sys
                    if sys.argv[1:] == ['-version']:
                        print('Xcode {xcode_version}.0\\nBuild version fixture')
                        raise SystemExit(0)
                    print('fixture native compiler invocation')
                    print('Guide.swift:26:15: error: extra trailing closure passed in call', file=sys.stderr)
                    print('26 | }} footer: {{', file=sys.stderr)
                    raise SystemExit(65)
                """),
            }
            for name, content in commands.items():
                path = binaries / name
                path.write_text(content)
                path.chmod(0o755)
            environment = dict(os.environ)
            environment["PATH"] = str(binaries) + os.pathsep + environment.get("PATH", "")
            result = subprocess.run(["bash", str(scripts / "build-unsigned.sh")],
                                    cwd=project, env=environment, text=True,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=15)
            log = project / "build/xcodebuild.log"
            return result, log.read_text() if log.exists() else None, list(project.rglob("*.ipa"))

    def test_failed_build_preserves_exit_code_and_full_log_without_ipa(self):
        result, log, ipas = self.run_fixture(26)
        self.assertEqual(result.returncode, 65, result.stdout)
        self.assertIsNotNone(log)
        self.assertIn("error: extra trailing closure", log)
        self.assertIn("First compiler errors", result.stdout)
        self.assertFalse(ipas)

    def test_old_xcode_stops_before_build(self):
        result, log, ipas = self.run_fixture(16)
        self.assertEqual(result.returncode, 1, result.stdout)
        self.assertIn("requires Xcode 26", result.stdout)
        self.assertIsNone(log)
        self.assertFalse(ipas)


if __name__ == "__main__":
    unittest.main()
