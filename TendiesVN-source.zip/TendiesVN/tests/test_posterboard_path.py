#!/usr/bin/env python3
"""Test fixed PosterBoard path validation without Foundation or an iOS SDK.

Run: python3 tests/test_posterboard_path.py
"""
# SPDX-License-Identifier: GPL-3.0-only
import ctypes
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
PRIVATE_PREFIX = b"/private/var/mobile/Containers/Data/Application/"
ALIAS_PREFIX = b"/var/mobile/Containers/Data/Application/"
UUID = b"A1B2C3D4-1234-5678-9ABC-1234567890EF"
CAPACITY = len(PRIVATE_PREFIX) + 36 + 1


class PosterBoardPathTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build = tempfile.TemporaryDirectory(prefix="tendiesvn-path-build-")
        compiler = shutil.which("cc") or shutil.which("gcc") or shutil.which("clang")
        if compiler is None:
            raise RuntimeError("A C compiler is required")
        library = Path(cls.build.name) / "posterboard_path.so"
        shared_flag = "-dynamiclib" if sys.platform == "darwin" else "-shared"
        subprocess.run([
            compiler, "-std=c11", "-Wall", "-Wextra", "-Werror", "-fPIC", shared_flag,
            str(ROOT / "TendiesVN/Engine/posterboard_path.c"), "-o", str(library),
        ], check=True)
        cls.library = ctypes.CDLL(str(library))
        cls.canonicalize = cls.library.tendies_canonical_posterboard_root_path
        cls.canonicalize.argtypes = [
            ctypes.c_char_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.c_size_t,
        ]
        cls.canonicalize.restype = ctypes.c_int
        cls.candidate_root = cls.library.tendies_posterboard_candidate_root_path
        cls.candidate_root.argtypes = cls.canonicalize.argtypes
        cls.candidate_root.restype = ctypes.c_int

    @classmethod
    def tearDownClass(cls):
        cls.build.cleanup()

    def assert_path(self, raw, expected):
        self.assert_conversion(self.canonicalize, raw, expected)

    def assert_conversion(self, function, raw, expected):
        output = ctypes.create_string_buffer(CAPACITY)
        result = function(raw, len(raw), output, len(output))
        self.assertEqual(result, expected is not None)
        self.assertEqual(output.value, expected or b"")

    def test_both_aliases_and_single_trailing_slash(self):
        for prefix in [PRIVATE_PREFIX, ALIAS_PREFIX]:
            for uuid in [UUID, UUID.lower(), b"00000000-0000-0000-0000-000000000000"]:
                for trailing in [b"", b"/"]:
                    raw = prefix + uuid + trailing
                    with self.subTest(path=raw):
                        self.assert_path(raw, PRIVATE_PREFIX + uuid)

    def test_traversal_extra_components_and_other_roots_are_rejected(self):
        invalid = [
            b"", b"/", PRIVATE_PREFIX, PRIVATE_PREFIX[:-1],
            b"/private/var/mobile/Containers/Data/ApplicationX/" + UUID,
            b"/private/var/mobile/Containers/Data/System/" + UUID,
            b"/var/mobile/Containers/Shared/AppGroup/" + UUID,
            b"//private/var/mobile/Containers/Data/Application/" + UUID,
            b"/private//var/mobile/Containers/Data/Application/" + UUID,
            PRIVATE_PREFIX + b"/" + UUID,
            PRIVATE_PREFIX + b"./" + UUID,
            PRIVATE_PREFIX + b"../Application/" + UUID,
            ALIAS_PREFIX + b"../../Data/Application/" + UUID,
            PRIVATE_PREFIX + UUID + b"//",
            PRIVATE_PREFIX + UUID + b"/.",
            PRIVATE_PREFIX + UUID + b"/..",
            PRIVATE_PREFIX + UUID + b"/Library",
            PRIVATE_PREFIX + UUID + b"/../" + UUID,
            b"file://" + PRIVATE_PREFIX + UUID,
            b"~" + ALIAS_PREFIX + UUID,
            PRIVATE_PREFIX + UUID + b" ",
            PRIVATE_PREFIX + UUID + b"\n",
        ]
        for raw in invalid:
            with self.subTest(path=raw):
                self.assert_path(raw, None)

    def test_uuid_requires_exact_ascii_hex_and_hyphens(self):
        invalid = [
            UUID[:-1], UUID + b"0", UUID.replace(b"-", b""),
            UUID.replace(b"-", b"_"), UUID.replace(b"A", b"G", 1),
            b"{" + UUID + b"}", b"urn:uuid:" + UUID,
            b" " + UUID, UUID + b" ",
        ]
        for uuid in invalid:
            with self.subTest(uuid=uuid):
                self.assert_path(PRIVATE_PREFIX + uuid, None)

    def test_embedded_nul_and_unicode_do_not_truncate_into_valid_paths(self):
        for raw in [
            PRIVATE_PREFIX + UUID + b"\0/Library",
            PRIVATE_PREFIX + UUID + b"\0",
            PRIVATE_PREFIX + UUID.replace(b"A", b"\0", 1),
            PRIVATE_PREFIX + UUID.replace(b"A", "Ａ".encode(), 1),
        ]:
            with self.subTest(path=raw):
                self.assert_path(raw, None)

    def test_missing_or_short_output_is_rejected_and_cleared(self):
        raw = PRIVATE_PREFIX + UUID
        for capacity in [1, CAPACITY - 1]:
            output = ctypes.create_string_buffer(b"x" * capacity, capacity)
            self.assertEqual(self.canonicalize(raw, len(raw), output, capacity), 0)
            self.assertEqual(output.value, b"")
        untouched = ctypes.create_string_buffer(b"keep")
        self.assertEqual(self.canonicalize(raw, len(raw), untouched, 0), 0)
        self.assertEqual(untouched.value, b"keep")
        self.assertEqual(self.canonicalize(raw, len(raw), None, CAPACITY), 0)
        self.assertEqual(self.canonicalize(None, 0, untouched, len(untouched)), 0)
        self.assertEqual(untouched.value, b"")

    def test_valid_in_place_alias_conversion(self):
        for prefix in [PRIVATE_PREFIX, ALIAS_PREFIX]:
            raw = prefix + UUID
            output = ctypes.create_string_buffer(raw, CAPACITY)
            self.assertEqual(self.canonicalize(output, len(raw), output, len(output)), 1)
            self.assertEqual(output.value, PRIVATE_PREFIX + UUID)

    def test_candidate_accepts_roots_and_returns_only_canonical_root(self):
        for prefix in [PRIVATE_PREFIX, ALIAS_PREFIX]:
            for uuid in [UUID, UUID.lower(), b"00000000-0000-0000-0000-000000000000"]:
                for trailing in [b"", b"/"]:
                    raw = prefix + uuid + trailing
                    with self.subTest(path=raw):
                        self.assert_conversion(self.candidate_root, raw, PRIVATE_PREFIX + uuid)

    def test_candidate_accepts_descendants_but_strict_validator_never_does(self):
        descendants = [
            b"/Library",
            b"/Library/",
            b"/Library/Application Support/PosterBoard/posters/01234567/data",
            b"/Library/.cache/foo..bar/..metadata",
            "/Library/Hình nền/ảnh.png".encode(),
        ]
        for prefix in [PRIVATE_PREFIX, ALIAS_PREFIX]:
            for uuid in [UUID, UUID.lower()]:
                for descendant in descendants:
                    raw = prefix + uuid + descendant
                    with self.subTest(path=raw):
                        self.assert_conversion(self.candidate_root, raw, PRIVATE_PREFIX + uuid)
                        self.assert_path(raw, None)

    def test_candidate_rejects_malformed_roots_and_uuids(self):
        invalid = [
            b"", b"/", PRIVATE_PREFIX, PRIVATE_PREFIX[:-1],
            b"/private/var/mobile/Containers/Data/ApplicationX/" + UUID + b"/Library",
            b"/var/mobile/Containers/Data/System/" + UUID + b"/Library",
            b"/var/mobile/Containers/Shared/AppGroup/" + UUID + b"/Library",
            b"//private/var/mobile/Containers/Data/Application/" + UUID + b"/Library",
            b"/private//var/mobile/Containers/Data/Application/" + UUID + b"/Library",
            b"file://" + PRIVATE_PREFIX + UUID + b"/Library",
            b"~" + ALIAS_PREFIX + UUID + b"/Library",
            PRIVATE_PREFIX + b"/" + UUID + b"/Library",
            PRIVATE_PREFIX + b"./" + UUID + b"/Library",
            PRIVATE_PREFIX + b"../Application/" + UUID + b"/Library",
        ]
        for uuid in [
            UUID[:-1], UUID + b"0", UUID.replace(b"-", b""),
            UUID.replace(b"-", b"_"), UUID.replace(b"A", b"G", 1),
            b"{" + UUID + b"}", b"urn:uuid:" + UUID,
            b" " + UUID, UUID + b" ",
            UUID.replace(b"A", "Ａ".encode(), 1),
        ]:
            invalid.append(PRIVATE_PREFIX + uuid + b"/Library")
        for raw in invalid:
            with self.subTest(path=raw):
                self.assert_conversion(self.candidate_root, raw, None)

    def test_candidate_rejects_malformed_descendants_without_normalizing(self):
        suffixes = [
            b"//", b"//Library", b"/Library//posters", b"/Library//",
            b"/.", b"/./", b"/..", b"/../", b"/./Library", b"/../Library",
            b"/Library/.", b"/Library/./", b"/Library/..", b"/Library/../",
            b"/Library/./posters", b"/Library/../posters",
            b"\\Library", b"/Library\\posters", b"/Library/\\/posters",
        ]
        for prefix in [PRIVATE_PREFIX, ALIAS_PREFIX]:
            for suffix in suffixes:
                raw = prefix + UUID + suffix
                with self.subTest(path=raw):
                    self.assert_conversion(self.candidate_root, raw, None)

    def test_candidate_rejects_embedded_nul_and_every_ascii_control_character(self):
        for prefix in [PRIVATE_PREFIX, ALIAS_PREFIX]:
            root = prefix + UUID
            for character in list(range(32)) + [127]:
                for raw in [
                    root + bytes([character]),
                    root + b"/Library/" + bytes([character]) + b"posters",
                    root + b"/Library/posters" + bytes([character]),
                ]:
                    with self.subTest(path=raw):
                        self.assert_conversion(self.candidate_root, raw, None)
            raw = prefix + UUID.replace(b"A", b"\0", 1) + b"/Library"
            self.assert_conversion(self.candidate_root, raw, None)

    def test_candidate_missing_or_short_output_is_rejected_and_cleared(self):
        for raw in [PRIVATE_PREFIX + UUID, ALIAS_PREFIX + UUID + b"/Library/posters"]:
            for capacity in [1, CAPACITY - 1]:
                output = ctypes.create_string_buffer(b"x" * capacity, capacity)
                self.assertEqual(self.candidate_root(raw, len(raw), output, capacity), 0)
                self.assertEqual(output.value, b"")
            untouched = ctypes.create_string_buffer(b"keep")
            self.assertEqual(self.candidate_root(raw, len(raw), untouched, 0), 0)
            self.assertEqual(untouched.value, b"keep")
            self.assertEqual(self.candidate_root(raw, len(raw), None, CAPACITY), 0)
        output = ctypes.create_string_buffer(b"keep")
        self.assertEqual(self.candidate_root(None, 0, output, len(output)), 0)
        self.assertEqual(output.value, b"")

    def test_candidate_valid_in_place_alias_conversion_and_descendant_extraction(self):
        for prefix in [PRIVATE_PREFIX, ALIAS_PREFIX]:
            for suffix in [b"", b"/", b"/Library/Application Support/posters", b"/Library/"]:
                raw = prefix + UUID + suffix
                output = ctypes.create_string_buffer(raw, max(CAPACITY, len(raw) + 1))
                with self.subTest(path=raw):
                    self.assertEqual(self.candidate_root(output, len(raw), output, len(output)), 1)
                    self.assertEqual(output.value, PRIVATE_PREFIX + UUID)


if __name__ == "__main__":
    unittest.main()
