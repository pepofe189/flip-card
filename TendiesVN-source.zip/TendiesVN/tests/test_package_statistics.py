#!/usr/bin/env python3
"""Exercise actual extracted-package statistics with bounded temporary fixtures."""
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class PackageStatisticsTests(unittest.TestCase):
    @unittest.skipUnless(sys.platform == "darwin" and shutil.which("swiftc"), "requires macOS Foundation and Swift")
    def test_complete_tree_counts_and_size_bounds(self):
        with tempfile.TemporaryDirectory(prefix="1809-package-statistics-") as directory:
            binary = Path(directory) / "statistics-tests"
            subprocess.run([
                shutil.which("swiftc"), "-swift-version", "5",
                "-target", platform.machine() + "-apple-macosx13.0",
                str(ROOT / "TendiesVN/Engine/WallpaperLabModels.swift"),
                str(ROOT / "TendiesVN/Engine/WallpaperPackageStatistics.swift"),
                str(ROOT / "tests/WallpaperPackageStatisticsTests.swift"), "-o", str(binary),
            ], check=True, timeout=120)
            subprocess.run([str(binary)], check=True, timeout=30)


if __name__ == "__main__":
    unittest.main()
