#!/usr/bin/env python3
"""Run the production view model with controlled device/launcher boundaries."""
from pathlib import Path
import shutil
import platform
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class WallpaperModelFlowTests(unittest.TestCase):
    @unittest.skipUnless(sys.platform == "darwin" and shutil.which("swiftc"), "requires macOS SwiftUI and Swift")
    def test_completion_and_failure_do_not_launch_posterboard_early(self):
        with tempfile.TemporaryDirectory(prefix="1809-model-flow-") as directory:
            binary = Path(directory) / "model-flow-tests"
            subprocess.run([
                shutil.which("swiftc"), "-parse-as-library", "-swift-version", "5",
                "-target", platform.machine() + "-apple-macosx13.0",
                str(ROOT / "TendiesVN/App/WallpaperModel.swift"),
                str(ROOT / "tests/WallpaperModelFlowTests.swift"), "-o", str(binary),
            ], check=True, timeout=120)
            subprocess.run([str(binary)], check=True, timeout=30)


if __name__ == "__main__":
    unittest.main()
