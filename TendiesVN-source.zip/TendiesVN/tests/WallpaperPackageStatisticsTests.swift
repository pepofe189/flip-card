import Foundation

@main
struct WallpaperPackageStatisticsTests {
    static func main() throws {
        let fm = FileManager.default
        let root = fm.temporaryDirectory.appendingPathComponent("1809-statistics-\(UUID())", isDirectory: true)
        try fm.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: root) }
        let nested = root.appendingPathComponent("descriptors/Wallpaper/versions/1", isDirectory: true)
        try fm.createDirectory(at: nested, withIntermediateDirectories: true)
        try Data([1, 2, 3]).write(to: nested.appendingPathComponent("asset.resource"))
        // Documentation outside descriptors and hidden/empty resources still
        // occupy extracted files. Directories themselves are not counted.
        try Data("Notes".utf8).write(to: root.appendingPathComponent("README.txt"))
        try Data([4, 5]).write(to: root.appendingPathComponent(".metadata"))
        try Data().write(to: root.appendingPathComponent("empty"))
        let stats = try WallpaperPackageStatistics.inspect(at: root)
        precondition(stats.fileCount == 4 && stats.expandedBytes == 10)
        // Symbolic links must not count outside files or follow another root.
        let link = root.appendingPathComponent("external-link")
        try fm.createSymbolicLink(at: link, withDestinationURL: fm.temporaryDirectory)
        var rejected = false
        do { _ = try WallpaperPackageStatistics.inspect(at: root) }
        catch WallpaperLabError.symbolicLinkUnsupported { rejected = true }
        precondition(rejected)
        try fm.removeItem(at: link)
        // Read metadata only: a sparse oversized file must hit the same package
        // bounds without allocating or loading its contents into memory.
        let oversized = root.appendingPathComponent("oversized")
        precondition(fm.createFile(atPath: oversized.path, contents: nil))
        let handle = try FileHandle(forWritingTo: oversized)
        try handle.truncate(atOffset: UInt64(WallpaperLabLimits.maximumEntryBytes + 1))
        try handle.close()
        rejected = false
        do { _ = try WallpaperPackageStatistics.inspect(at: root) }
        catch WallpaperLabError.packageTooLarge { rejected = true }
        precondition(rejected)
        print("Package statistics: complete extracted tree, regular-file count, logical sizes, symlink and size bounds passed.")
    }
}
