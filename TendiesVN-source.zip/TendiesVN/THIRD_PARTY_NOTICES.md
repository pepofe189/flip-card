# Third-party notices and source provenance

1809 3.5.0 (build 19) restores the scoped PosterBoard package installer and launcher from 1809 build 14. The Photos export workflow, media previews and detail gallery have been removed. After a committed write the app opens PosterBoard; the user closes its card in the app switcher and selects wallpaper in iOS Settings.

## 3105 and restored installer

- Author: YangJiii and contributors.
- Source: <https://github.com/YangJiiii/3105>.
- Reference commit: `a72617ed4c764a65d8aac1e91aca95231e72a2cb`.
- License for upstream portions: GNU GPL version 3; included as `LICENSE`.
- Adaptations: bounded ZIP extraction, package inspection, sandbox-local package storage, descriptor parsing/rewriting, installation journals, rollback/restore, scoped PosterBoard access and native launcher.
- `PosterBoardBridge.m` retains the `bad_query` sandbox-extension technique attributed by upstream to forcequitOS. Its bounded filesystem/metadata discovery also follows Placard/Bad-Poster's approach, as noted in the source.
- The bridge checks the fixed Application/UUID root and verifies `MCMMetadataIdentifier` equals `com.apple.PosterBoard` before granting retained root access. This is a private iOS mechanism, not a public-API wallpaper feature.
- The existing BadQuery mechanism is retained; build 19 shares a C version/build predicate between Swift and the native bridge. It accepts iOS 26.0–26.6.1 and exact iOS 27.0 beta builds cross-checked against Placard. The Airlift route accepts iOS 27.0–27.0.1 through an imported pairing record. iOS 18 remains app/library-only in 1809.
- `DeviceCompatibility.swift` references iOS 27 beta labels from upstream `SupportPolicy.swift` and the revised iPad build from Placard. Labels are not device test results.

No new kernel access chain, general system-container browser, Wallet/passcode tool, patch engine, cleaner or editor is bundled. The AirliftFFI binary is included only for the restricted PosterBoard writer route and its MIT notice is in `ThirdParty/AirCard-Airlift-LICENSE.txt`. The launcher is restricted to `com.apple.PosterBoard`; it does not kill system processes or automatically open the app switcher.

## AirCard-iOS / Airlift

- Source reference: <https://github.com/Mak5er/AirCard-iOS>.
- License: MIT, included as `ThirdParty/AirCard-Airlift-LICENSE.txt`.
- The bundled `AirliftFFI.xcframework` supplies the imported-pairing container lookup and directory injection used for iOS 27.0–27.0.1. It is not used for iOS 18 wallpaper installation; iOS 18 support in 1809 is limited to the app/library flow.

## Placard compatibility reference

- [Placard](https://github.com/frs0n/placard) by frs0n and contributors, commit `7dcefb610cc60ae909b6046beee7adb691148e44`.
- Its `SystemCompatibility.swift` exact beta build matrix and native BadQuery route were compared with the existing 1809 bridge. The Airlift route is kept separate because it requires an imported pairing record.
- Full comparison and primary permalinks: [UPSTREAM-COMPATIBILITY.md](UPSTREAM-COMPATIBILITY.md).

## Pocket Poster and format references

- [Pocket-Poster](https://github.com/leminlimez/Pocket-Poster) by LeminLimez and contributors: wallpaper archive/format reference; GPL-3.0.
- 3105 acknowledges Pocket Poster/Nugget for wallpaper formats. The Nugget application is not bundled.

Imported packages, their media and embedded attribution keep their own copyrights. Renaming this application does not change those rights.

## Pairing transport

- [idevice](https://github.com/jkcoxson/idevice), Jackson Coxson and contributors, version `v0.1.68`.
- MIT license included in `ThirdParty/idevice-LICENSE.txt`.
- The build helper downloads the pinned release and verifies its checksum. Pairing uses authenticated device sessions and the user's imported/generated record; it does not supply this installer's wallpaper access.
- LocalDevVPN is a separate linked app and is not bundled.

## System frameworks and 1809 changes

Foundation, SwiftUI, UIKit, UniformTypeIdentifiers, Security, Network and SystemConfiguration are Apple system frameworks. The restored scoped launcher uses private LaunchServices selectors. The app no longer requests Photos authorization or creates Photos assets.

The Vietnamese UI, minimal library, six accent presets/custom appearance, compact settings, complete extracted-package statistics, status UI, build diagnostics, validation and packaging are adapted or implemented for 1809. No certificate, private signing key, pairing record, provisioning profile, prebuilt dependency archive or signed IPA is included in this source ZIP.
