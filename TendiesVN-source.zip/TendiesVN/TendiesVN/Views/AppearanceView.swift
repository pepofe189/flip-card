import SwiftUI

struct AppearanceView: View {
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @AppStorage("1809.appearance") private var appearance = AppAppearance.system.rawValue
    @AppStorage("1809.accentHex") private var accentHex = AppTheme.defaultAccentHex

    private var accent: Color { AppTheme.accentColor(hex: accentHex) }
    private var selectedAppearance: AppAppearance { AppAppearance(rawValue: appearance) ?? .system }
    private var selectedPreset: AppAccentPreset? {
        AppTheme.presets.first { $0.hex.caseInsensitiveCompare(accentHex) == .orderedSame }
    }
    private var presetColumns: [GridItem] {
        Array(repeating: GridItem(.flexible(), spacing: 12),
              count: dynamicTypeSize.isAccessibilitySize ? 2 : 3)
    }
    private var customColor: Binding<Color> {
        Binding(get: { accent }, set: { accentHex = AppTheme.hex(from: $0) })
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                preview
                VStack(alignment: .leading, spacing: 12) {
                    sectionHeading("Chế độ hiển thị", subtitle: "Chọn cách ứng dụng xuất hiện.")
                    VStack(spacing: 0) {
                        ForEach(AppAppearance.allCases) { mode in
                            Button { appearance = mode.rawValue } label: {
                                HStack(spacing: 14) {
                                    Image(systemName: mode.systemImage)
                                        .font(.title3)
                                        .frame(width: 28)
                                        .foregroundStyle(accent)
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(mode.title).font(.body.weight(.medium)).foregroundStyle(.primary)
                                        Text(mode.subtitle).font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer(minLength: 8)
                                    Image(systemName: selectedAppearance == mode ? "checkmark.circle.fill" : "circle")
                                        .font(.title3)
                                        .foregroundStyle(selectedAppearance == mode ? accent : Color.secondary.opacity(0.35))
                                }
                                .padding(18)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityAddTraits(selectedAppearance == mode ? [.isSelected] : [])
                            if mode != AppAppearance.allCases.last {
                                Divider().padding(.leading, 60)
                            }
                        }
                    }
                    .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 22))
                }
                VStack(alignment: .leading, spacing: 14) {
                    sectionHeading("Màu nhấn", subtitle: "Dùng cho nút, liên kết và mục đang chọn.")
                    LazyVGrid(columns: presetColumns, spacing: 12) {
                        ForEach(AppTheme.presets) { preset in
                            presetButton(preset)
                        }
                    }
                    ColorPicker(selection: customColor, supportsOpacity: false) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Màu của bạn").font(.body.weight(.medium))
                            Text(selectedPreset == nil ? "Tùy chỉnh · #\(accentHex.uppercased())" : "Chọn một màu bất kỳ")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    .padding(18)
                    .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 20))
                    Text("Trạng thái luôn dùng xanh lá cho thành công, đỏ cho lỗi hoặc không hỗ trợ và vàng khi cần thao tác.")
                        .font(.footnote).foregroundStyle(.secondary)
                        .padding(.horizontal, 4)
                }
                Button {
                    appearance = AppAppearance.system.rawValue
                    accentHex = AppTheme.defaultAccentHex
                } label: {
                    Label("Khôi phục giao diện mặc định", systemImage: "arrow.counterclockwise")
                        .font(.subheadline.weight(.medium))
                        .frame(maxWidth: .infinity, minHeight: 48)
                }
                .buttonStyle(.bordered)
            }
            .padding(20)
            .padding(.bottom, 12)
        }
        .background(Color.appBackground)
        .navigationTitle("Giao diện")
        .navigationBarTitleDisplayMode(.large)
    }

    private var preview: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                Label("Xem trước", systemImage: "paintpalette")
                    .font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                Spacer()
                Text(selectedPreset?.title ?? "Tùy chỉnh")
                    .font(.caption.weight(.semibold)).foregroundStyle(accent)
            }
            HStack(spacing: 14) {
                Image(systemName: "photo.on.rectangle.angled")
                    .font(.title2)
                    .foregroundStyle(accent)
                    .frame(width: 48, height: 48)
                    .background(accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
                VStack(alignment: .leading, spacing: 4) {
                    Text("Hình nền của bạn").font(.headline)
                    Text("Một chút màu, theo ý bạn.").font(.caption).foregroundStyle(.secondary)
                }
            }
            ViewThatFits(in: .horizontal) {
                HStack {
                    previewStatus
                    Spacer(minLength: 4)
                    previewAction
                }
                VStack(alignment: .leading, spacing: 12) {
                    previewStatus
                    previewAction
                }
            }
        }
        .padding(20)
        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 24))
        .overlay(alignment: .top) {
            Capsule().fill(accent).frame(width: 44, height: 4).padding(.top, 0)
                .accessibilityHidden(true)
        }
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Bản xem trước giao diện, không phải trạng thái kết nối thực tế")
    }

    private var previewStatus: some View {
        StatusBadge(title: "Thành công", systemImage: "checkmark.circle.fill", tone: .success)
    }

    private var previewAction: some View {
        Text("+ Nhập gói")
            .font(.caption.weight(.semibold))
            .foregroundStyle(AppTheme.foregroundColor(hex: accentHex))
            .padding(.horizontal, 14).padding(.vertical, 9)
            .background(accent, in: Capsule())
            .accessibilityLabel("Xem trước nút nhập gói")
    }

    private func sectionHeading(_ title: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.title3.bold())
            Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
        }
        .padding(.horizontal, 4)
    }

    private func presetButton(_ preset: AppAccentPreset) -> some View {
        let selected = selectedPreset?.id == preset.id
        let color = AppTheme.accentColor(hex: preset.hex)
        return Button { accentHex = preset.hex } label: {
            VStack(spacing: 9) {
                ZStack {
                    Circle().fill(color).frame(width: 32, height: 32)
                    if selected {
                        Image(systemName: "checkmark").font(.caption.bold())
                            .foregroundStyle(AppTheme.foregroundColor(hex: preset.hex))
                    }
                }
                Text(preset.title).font(.caption.weight(selected ? .semibold : .regular))
                    .foregroundStyle(.primary)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity)
            .padding(.horizontal, 8)
            .padding(.vertical, 15)
            .background(selected ? color.opacity(0.10) : Color.appSurface,
                        in: RoundedRectangle(cornerRadius: 18))
            .overlay {
                RoundedRectangle(cornerRadius: 18)
                    .strokeBorder(selected ? color : .clear, lineWidth: 1.5)
            }
            .contentShape(RoundedRectangle(cornerRadius: 18))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Màu \(preset.title)")
        .accessibilityAddTraits(selected ? [.isSelected] : [])
    }
}
