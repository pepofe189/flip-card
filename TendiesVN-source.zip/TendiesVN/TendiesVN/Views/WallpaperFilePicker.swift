import SwiftUI
import UIKit
import UniformTypeIdentifiers

/// Use the document-import path so File Providers return a local copy, and
/// include all known registrations for this third-party filename extension.
struct WallpaperFilePicker: UIViewControllerRepresentable {
    let onPick: (URL) -> Void
    let onCancel: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        var seen = Set<String>()
        let registrations = UTType.types(
            tag: "tendies", tagClass: .filenameExtension, conformingTo: nil
        )
        let fallbacks: [UTType] = [.tendiesPackage, .zip, .archive, .data, .content, .item]
        let types = (registrations + fallbacks).filter { seen.insert($0.identifier).inserted }
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: true)
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = false
        picker.shouldShowFileExtensions = true
        return picker
    }

    func updateUIViewController(_ picker: UIDocumentPickerViewController, context: Context) {
        context.coordinator.parent = self
    }

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        var parent: WallpaperFilePicker
        private var finished = false

        init(parent: WallpaperFilePicker) { self.parent = parent }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard !finished else { return }
            finished = true
            if let url = urls.first { parent.onPick(url) }
            else { parent.onCancel() }
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            guard !finished else { return }
            finished = true
            parent.onCancel()
        }
    }
}
