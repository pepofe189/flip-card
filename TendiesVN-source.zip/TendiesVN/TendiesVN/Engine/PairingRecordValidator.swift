import Foundation
import Security
import CryptoKit

enum PairingRecordKind: String, Codable {
    case lockdown = "Lockdown"
    case remote = "RPPairing"
}

struct PairingRecordSummary: Codable, Equatable {
    let fileName: String
    let importedAt: Date
    /// A filename or plist identifier is only a label. Public iOS APIs do not
    /// expose the current UDID, so it cannot establish a device match.
    let deviceIdentifier: String?
    var kind: PairingRecordKind? = nil
    var byteCount: Int? = nil

    var maskedDeviceIdentifier: String? {
        guard let deviceIdentifier else { return nil }
        return String(deviceIdentifier.prefix(4)) + "…" + String(deviceIdentifier.suffix(4))
    }
}

struct StoredPairingRecord: Codable {
    let summary: PairingRecordSummary
    let plistData: Data
}

enum PairingImportError: LocalizedError {
    case invalidFile
    case tooLarge
    case invalidRecord
    case missingField(String)
    case invalidCertificate
    case invalidPrivateKey
    case mismatchedKey
    case keychain(OSStatus)

    var errorDescription: String? {
        switch self {
        case .invalidFile:
            return "Chọn tệp pairing .mobiledevicepairing hoặc .plist được tạo trên máy tính."
        case .tooLarge:
            return "Tệp pairing vượt quá giới hạn 1 MB."
        case .invalidRecord:
            return "Tệp không phải bản ghi pairing hợp lệ. Tạo lại bản ghi bằng JitterbugPair trên máy tính."
        case .missingField(let field):
            return "Bản ghi pairing thiếu hoặc sai trường \(field). Hãy tạo lại bản ghi trên máy tính."
        case .invalidCertificate:
            return "Chứng chỉ trong bản ghi pairing không hợp lệ."
        case .invalidPrivateKey:
            return "Khoá riêng trong bản ghi pairing không hợp lệ hoặc có mã hoá."
        case .mismatchedKey:
            return "Khoá và chứng chỉ trong bản ghi pairing không khớp nhau."
        case .keychain(let status):
            if status == errSecInteractionNotAllowed {
                return "Mở khoá thiết bị rồi thử lại để truy cập bản ghi pairing trong Keychain."
            }
            return "Không thể cập nhật bản ghi pairing trong Keychain (\(status))."
        }
    }
}

/// Validates the local credential structure and key pairs only. It does not
/// contact lockdownd or attest that this record belongs to the running device.
enum PairingRecordValidator {
    static let maximumBytes = 1_024 * 1_024

    static func validate(_ data: Data) throws -> [String: Any] {
        guard !data.isEmpty else { throw PairingImportError.invalidRecord }
        guard data.count <= maximumBytes else { throw PairingImportError.tooLarge }
        guard let plist = try? PropertyListSerialization.propertyList(
            from: data, options: [], format: nil
        ), let record = plist as? [String: Any] else {
            throw PairingImportError.invalidRecord
        }
        if kind(of: record) == .remote {
            try validateRemote(record)
            return record
        }
        for name in ["HostID", "SystemBUID"] {
            guard let identifier = record[name] as? String,
                  UUID(uuidString: identifier) != nil else {
                throw PairingImportError.missingField(name)
            }
        }
        let hostCertificate = try certificate(record, field: "HostCertificate")
        let rootCertificate = try certificate(record, field: "RootCertificate")
        _ = try certificate(record, field: "DeviceCertificate")
        let hostKey = try privateKey(record, field: "HostPrivateKey")
        let rootKey = try privateKey(record, field: "RootPrivateKey")
        try validateKeyPair(hostKey, certificate: hostCertificate)
        try validateKeyPair(rootKey, certificate: rootCertificate)
        if let escrow = record["EscrowBag"] {
            guard let bytes = escrow as? Data, !bytes.isEmpty,
                  bytes.count <= maximumBytes / 2 else {
                throw PairingImportError.missingField("EscrowBag")
            }
        }
        return record
    }

    static func kind(of record: [String: Any]) -> PairingRecordKind {
        record["private_key"] != nil || record["public_key"] != nil || record["identifier"] != nil
            ? .remote : .lockdown
    }

    static func nativeData(_ record: [String: Any]) throws -> Data {
        var normalized = record
        if kind(of: record) == .lockdown {
            for field in ["HostCertificate", "RootCertificate", "DeviceCertificate", "HostPrivateKey", "RootPrivateKey"] {
                let isKey = field.hasSuffix("PrivateKey")
                var data = try der(bytes(record, field: field), labels: isKey ? ["RSA PRIVATE KEY", "PRIVATE KEY"] : ["CERTIFICATE"])
                if isKey { data = try rsaPrivateKeyData(data) }
                let label = isKey ? "RSA PRIVATE KEY" : "CERTIFICATE"
                let encoded = data.base64EncodedString(options: [.lineLength64Characters, .endLineWithLineFeed])
                normalized[field] = Data("-----BEGIN \(label)-----\n\(encoded)\n-----END \(label)-----\n".utf8)
            }
            if normalized["WiFiMACAddress"] == nil { normalized["WiFiMACAddress"] = "" }
        }
        return try PropertyListSerialization.data(fromPropertyList: normalized, format: .binary, options: 0)
    }

    private static func validateRemote(_ record: [String: Any]) throws {
        guard let identifier = record["identifier"] as? String,
              !identifier.isEmpty, identifier.utf8.count <= 255,
              !identifier.unicodeScalars.contains(where: CharacterSet.controlCharacters.contains),
              let privateBytes = record["private_key"] as? Data, privateBytes.count == 32,
              let publicBytes = record["public_key"] as? Data, publicBytes.count == 32 else {
            throw PairingImportError.invalidRecord
        }
        let key = try Curve25519.Signing.PrivateKey(rawRepresentation: privateBytes)
        guard key.publicKey.rawRepresentation == publicBytes else {
            throw PairingImportError.mismatchedKey
        }
        if let irk = record["alt_irk"] {
            guard let bytes = irk as? Data, bytes.count == 16 else {
                throw PairingImportError.missingField("alt_irk")
            }
        }
    }

    private static func bytes(_ record: [String: Any], field: String) throws -> Data {
        let data: Data
        if let value = record[field] as? Data {
            data = value
        } else if let value = record[field] as? String, let bytes = value.data(using: .utf8) {
            data = bytes
        } else {
            throw PairingImportError.missingField(field)
        }
        guard !data.isEmpty, data.count <= 128 * 1_024 else {
            throw PairingImportError.missingField(field)
        }
        return data
    }

    private static func der(_ data: Data, labels: [String]) throws -> Data {
        guard let text = String(data: data, encoding: .utf8), text.contains("-----BEGIN ") else {
            return data
        }
        let content = text.trimmingCharacters(in: .whitespacesAndNewlines)
        for label in labels {
            let begin = "-----BEGIN \(label)-----"
            let end = "-----END \(label)-----"
            guard content.hasPrefix(begin), content.hasSuffix(end) else { continue }
            let body = content.dropFirst(begin.count).dropLast(end.count)
            let compact = body.filter { !$0.isWhitespace }
            guard let decoded = Data(base64Encoded: String(compact)), !decoded.isEmpty else {
                throw PairingImportError.invalidRecord
            }
            return decoded
        }
        throw PairingImportError.invalidRecord
    }

    private static func certificate(_ record: [String: Any], field: String) throws -> SecCertificate {
        let data = try der(bytes(record, field: field), labels: ["CERTIFICATE"])
        guard let certificate = SecCertificateCreateWithData(nil, data as CFData) else {
            throw PairingImportError.invalidCertificate
        }
        return certificate
    }

    private static func privateKey(_ record: [String: Any], field: String) throws -> SecKey {
        let encoded = try der(bytes(record, field: field), labels: ["RSA PRIVATE KEY", "PRIVATE KEY"])
        let data = try rsaPrivateKeyData(encoded)
        let attributes: [String: Any] = [
            kSecAttrKeyType as String: kSecAttrKeyTypeRSA,
            kSecAttrKeyClass as String: kSecAttrKeyClassPrivate
        ]
        guard let key = SecKeyCreateWithData(data as CFData, attributes as CFDictionary, nil) else {
            throw PairingImportError.invalidPrivateKey
        }
        return key
    }

    /// SecKeyCreateWithData expects an RSA PKCS#1 key on iOS. OpenSSL tools
    /// also export PKCS#8 (BEGIN PRIVATE KEY), so unwrap that bounded DER
    /// container after checking the rsaEncryption algorithm identifier.
    private static func rsaPrivateKeyData(_ data: Data) throws -> Data {
        var document = DERReader(data)
        let sequence = try document.read(tag: 0x30)
        guard document.isAtEnd else { throw PairingImportError.invalidPrivateKey }
        var content = DERReader(sequence)
        let version = try content.read(tag: 0x02)
        if content.nextTag == 0x02 { return data } // PKCS#1, parsed by Security.
        guard version == Data([0]), content.nextTag == 0x30 else {
            throw PairingImportError.invalidPrivateKey
        }
        var algorithm = DERReader(try content.read(tag: 0x30))
        let rsaEncryptionOID = Data([0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x01, 0x01])
        guard try algorithm.read(tag: 0x06) == rsaEncryptionOID else {
            throw PairingImportError.invalidPrivateKey
        }
        if !algorithm.isAtEnd {
            guard try algorithm.read(tag: 0x05).isEmpty, algorithm.isAtEnd else {
                throw PairingImportError.invalidPrivateKey
            }
        }
        let privateKey = try content.read(tag: 0x04)
        // PrivateKeyInfo may carry optional context-specific attributes.
        if !content.isAtEnd { _ = try content.read(tag: 0xA0) }
        guard content.isAtEnd, !privateKey.isEmpty else {
            throw PairingImportError.invalidPrivateKey
        }
        return privateKey
    }

    private struct DERReader {
        private let bytes: [UInt8]
        private var offset = 0

        init(_ data: Data) { bytes = Array(data) }
        var isAtEnd: Bool { offset == bytes.count }
        var nextTag: UInt8? { offset < bytes.count ? bytes[offset] : nil }

        mutating func read(tag: UInt8) throws -> Data {
            guard offset < bytes.count, bytes[offset] == tag else {
                throw PairingImportError.invalidPrivateKey
            }
            offset += 1
            guard offset < bytes.count else { throw PairingImportError.invalidPrivateKey }
            let firstLength = bytes[offset]
            offset += 1
            var length = Int(firstLength)
            if firstLength & 0x80 != 0 {
                let count = Int(firstLength & 0x7F)
                guard count > 0, count <= 4, count <= bytes.count - offset,
                      bytes[offset] != 0 else { throw PairingImportError.invalidPrivateKey }
                length = 0
                for byte in bytes[offset..<(offset + count)] {
                    length = (length << 8) | Int(byte)
                }
                offset += count
                guard length >= 128 else { throw PairingImportError.invalidPrivateKey }
            }
            guard length <= bytes.count - offset else { throw PairingImportError.invalidPrivateKey }
            let value = Data(bytes[offset..<(offset + length)])
            offset += length
            return value
        }
    }

    private static func validateKeyPair(_ key: SecKey, certificate: SecCertificate) throws {
        guard let publicKey = SecCertificateCopyKey(certificate),
              SecKeyIsAlgorithmSupported(key, .sign, .rsaSignatureMessagePKCS1v15SHA256),
              SecKeyIsAlgorithmSupported(publicKey, .verify, .rsaSignatureMessagePKCS1v15SHA256) else {
            throw PairingImportError.invalidPrivateKey
        }
        // This is a local consistency check, never a claim of a device session.
        let challenge = Data(UUID().uuidString.utf8)
        guard let signature = SecKeyCreateSignature(
            key, .rsaSignatureMessagePKCS1v15SHA256, challenge as CFData, nil
        ), SecKeyVerifySignature(
            publicKey, .rsaSignatureMessagePKCS1v15SHA256,
            challenge as CFData, signature, nil
        ) else {
            throw PairingImportError.mismatchedKey
        }
    }

    static func deviceIdentifier(record: [String: Any], fileName: String) -> String? {
        let candidates = [record["UDID"] as? String, record["UniqueDeviceID"] as? String,
                          URL(fileURLWithPath: fileName).deletingPathExtension().lastPathComponent]
        return candidates.compactMap { $0 }.first { candidate in
            // Modern devices use an 8-16 hexadecimal UDID; older devices use 40.
            let groups = candidate.split(separator: "-", omittingEmptySubsequences: false)
            let validLength = (groups.count == 2 && groups[0].count == 8 && groups[1].count == 16)
                || (groups.count == 1 && candidate.count == 40)
            let allowed = CharacterSet(charactersIn: "0123456789abcdefABCDEF-")
            return validLength && candidate.unicodeScalars.allSatisfy(allowed.contains)
        }
    }
}

