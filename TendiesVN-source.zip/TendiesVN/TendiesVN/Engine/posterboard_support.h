// SPDX-License-Identifier: GPL-3.0-only
#ifndef TENDIES_POSTERBOARD_SUPPORT_H
#define TENDIES_POSTERBOARD_SUPPORT_H

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/// Whether the bundled PosterBoard backend recognizes this OS/build.
/// This pure policy check does not grant access or verify device write rights.
bool tendies_posterboard_backend_supports(
    int major,
    int minor,
    int patch,
    const char *build
);

#ifdef __cplusplus
}
#endif

#endif
