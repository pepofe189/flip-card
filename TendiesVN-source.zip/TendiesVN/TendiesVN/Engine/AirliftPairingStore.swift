import Foundation

/// Keeps an app-owned copy of the validated pairing record for Airlift.
/// Keychain remains the source of truth for the normal pairing UI; Airlift's
/// C API needs a filesystem path and cannot read the Keychain directly.
enum AirliftPairingStore {
    private static let directoryName = "Airlift"
    private static let pairingName = "pairing.plist"

    static var pairingURL: URL {
        let base = FileManager.default.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        ).first ?? FileManager.default.temporaryDirectory
        return base
            .appendingPathComponent("WallpaperLab", isDirectory: true)
            .appendingPathComponent(directoryName, isDirectory: true)
            .appendingPathComponent(pairingName)
    }

    static var hasPairing: Bool {
        let url = pairingURL
        guard let values = try? url.resourceValues(forKeys: [.isRegularFileKey]),
              values.isRegularFile == true else { return false }
        guard let data = try? Data(contentsOf: url) else { return false }
        return !data.isEmpty
    }

    static func save(_ data: Data) throws {
        let directory = pairingURL.deletingLastPathComponent()
        try FileManager.default.createDirectory(
            at: directory,
            withIntermediateDirectories: true,
            attributes: [.posixPermissions: 0o700]
        )
        try data.write(to: pairingURL, options: .atomic)
        try FileManager.default.setAttributes(
            [.posixPermissions: 0o600],
            ofItemAtPath: pairingURL.path
        )
    }

    static func remove() {
        try? FileManager.default.removeItem(at: pairingURL)
    }
}
