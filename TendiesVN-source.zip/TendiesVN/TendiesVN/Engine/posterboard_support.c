// SPDX-License-Identifier: GPL-3.0-only
// Build policy cross-checked against Placard's SystemCompatibility.swift,
// commit 7dcefb610cc60ae909b6046beee7adb691148e44. Compatibility metadata only;
// no kernel, sandbox, or installation operations are performed here.
#include "posterboard_support.h"

#include <stddef.h>
#include <string.h>

bool tendies_posterboard_backend_supports(
    int major,
    int minor,
    int patch,
    const char *build
) {
    if (major < 0 || minor < 0 || patch < 0) {
        return false;
    }

    if (major == 26) {
        return minor < 6 || (minor == 6 && patch <= 1);
    }

    if (major != 27 || minor != 0 || patch != 0 || build == NULL) {
        return false;
    }

    static const char *const recognized_builds[] = {
        "24A5355q",
        "24A5370h",
        "24A5380h",
        "24A5380l",
        "24A5390f",
    };
    for (size_t index = 0;
         index < sizeof(recognized_builds) / sizeof(recognized_builds[0]);
         ++index) {
        if (strcmp(build, recognized_builds[index]) == 0) {
            return true;
        }
    }
    return false;
}
