// SPDX-License-Identifier: GPL-3.0-only
// Adapted from 3105, YangJiii and contributors; modified 2026-10-17.
// Uses forcequitOS' bad_query technique without a fixed host Bundle ID.
// This bridge exposes only the PosterBoard container required by TendiesVN.
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
/// Returns a validated, retained-access PosterBoard root on iOS 26.0–26.6.1
/// or the exact iOS 27.0 beta builds in posterboard_support.c.
/// Works with the host app's normal Bundle ID. Call on a background queue;
/// initial, bounded metadata discovery can take time. No arbitrary-path API.
NSString * _Nullable TendiesPosterBoardContainerPath(
    NSString * _Nullable * _Nullable error
);
/// Pure validation of one fixed Application/UUID root. Accepts /var and
/// /private/var aliases and one optional trailing slash, without filesystem
/// queries, access grants, or Foundation path standardization. Returns the
/// canonical /private/var form, or nil for any other path. Safe on any queue.
NSString * _Nullable TendiesCanonicalPosterBoardRootPath(NSString *rawPath);
NS_ASSUME_NONNULL_END
