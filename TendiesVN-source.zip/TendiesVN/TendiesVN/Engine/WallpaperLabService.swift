// SPDX-License-Identifier: GPL-3.0-only
// Package import/validation adapted from 3105 (YangJiii and contributors).
// This service only reads and writes files inside the application's sandbox.
// See LICENSE and THIRD_PARTY_NOTICES.md.
import Foundation
import Darwin

struct WallpaperStagedPackage: Identifiable, Equatable {
    let id: UUID
    let displayName: String
    let repositoryIdentity: String?
    let packageDirectoryURL: URL
    let archiveURL: URL
    let extractedURL: URL
    let payload: TendiesPayload
    let importedAt: Date
    let statistics: WallpaperPackageStatistics
}

enum WallpaperPackageStore {
    private static let archiveName = "wallpaper.tendies"
    private static let extractedName = "Extracted"
    private static let metadataName = "metadata.plist"

    static func stagingRoot(fileManager: FileManager = .default) throws -> URL {
        let base = try applicationSupportURL(fileManager: fileManager)
        let url = base.appendingPathComponent("WallpaperLab/Packages", isDirectory: true)
        try createApprovedDirectory(url, fileManager: fileManager)
        return url
    }

    static func backupRoot(fileManager: FileManager = .default) throws -> URL {
        let base = try applicationSupportURL(fileManager: fileManager)
        let url = base.appendingPathComponent("WallpaperLab/Backups", isDirectory: true)
        try createApprovedDirectory(url, fileManager: fileManager)
        return url
    }

    static func importPackage(
        from sourceURL: URL,
        displayName: String? = nil,
        repositoryIdentity: String? = nil,
        fileManager: FileManager = .default
    ) throws -> WallpaperStagedPackage {
        let sourceExtension = sourceURL.pathExtension.lowercased()
        guard sourceURL.isFileURL,
              sourceExtension == "tendies" || sourceExtension == "zip" else {
            throw WallpaperLabError.unsupportedPackage
        }
        let didAccess = sourceURL.startAccessingSecurityScopedResource()
        defer {
            if didAccess { sourceURL.stopAccessingSecurityScopedResource() }
        }
        var filename = sourceURL.deletingPathExtension()
        if sourceExtension == "zip", filename.pathExtension.lowercased() == "tendies" {
            filename.deletePathExtension()
        }
        let resolvedDisplayName = (
            displayName ?? filename.lastPathComponent
        ).trimmingCharacters(in: .whitespacesAndNewlines)
        guard isValidMetadataText(resolvedDisplayName, maximumBytes: 255),
              repositoryIdentity.map({
                  isValidMetadataText($0, maximumBytes: 4_096)
              }) ?? true else {
            throw WallpaperLabError.unsupportedPackage
        }

        let root = try stagingRoot(fileManager: fileManager)
        let id = UUID()
        let importingURL = root.appendingPathComponent(
            ".importing-\(id.uuidString)",
            isDirectory: true
        )
        let finalURL = root.appendingPathComponent(id.uuidString, isDirectory: true)
        var movedToFinalDirectory = false
        do {
            try fileManager.createDirectory(
                at: importingURL,
                withIntermediateDirectories: false
            )
            let archiveURL = importingURL.appendingPathComponent(archiveName)
            // File providers can omit size/type resource values until a file is
            // materialized. Coordinate the read and inspect our private copy.
            try coordinatedCopyArchive(from: sourceURL, to: archiveURL)
            let copiedAttributes = try fileManager.attributesOfItem(atPath: archiveURL.path)
            guard copiedAttributes[.type] as? FileAttributeType == .typeRegular else {
                throw WallpaperLabError.symbolicLinkUnsupported
            }
            guard let copiedSize = copiedAttributes[.size] as? NSNumber else {
                throw WallpaperPackageReadFailure(underlyingError: NSError(
                    domain: NSCocoaErrorDomain, code: NSFileReadUnknownError
                ))
            }
            guard copiedSize.int64Value <= WallpaperLabLimits.maximumArchiveBytes else {
                throw WallpaperLabError.packageTooLarge
            }
            guard copiedSize.int64Value >= 22 else {
                throw WallpaperLabError.unsupportedPackage
            }
            let extractedURL = importingURL.appendingPathComponent(
                extractedName,
                isDirectory: true
            )
            // .zip is only a Files-picker fallback for the same .tendies bytes;
            // both extensions must pass the exact archive and descriptor checks.
            _ = try SecureZIPArchive.extract(
                archiveURL: archiveURL,
                destinationURL: extractedURL,
                fileManager: fileManager
            )
            _ = try TendiesPackageInspector.inspectExtractedPackage(
                at: extractedURL,
                fileManager: fileManager
            )
            let metadata = PackageMetadata(
                id: id,
                displayName: resolvedDisplayName,
                repositoryIdentity: repositoryIdentity,
                importedAt: Date()
            )
            let encoder = PropertyListEncoder()
            encoder.outputFormat = .binary
            try encoder.encode(metadata).write(
                to: importingURL.appendingPathComponent(metadataName),
                options: .atomic
            )
            guard rename(importingURL.path, finalURL.path) == 0 else {
                throw WallpaperLabError.unsafeArchive
            }
            movedToFinalDirectory = true
            let importedPackage = try loadPackage(
                at: finalURL,
                fileManager: fileManager
            )
            if let repositoryIdentity {
                for existingPackage in packages(fileManager: fileManager)
                where existingPackage.id != importedPackage.id
                    && existingPackage.repositoryIdentity == repositoryIdentity {
                    try? delete(existingPackage, fileManager: fileManager)
                }
            }
            return importedPackage
        } catch {
            try? fileManager.removeItem(at: importingURL)
            if movedToFinalDirectory {
                try? fileManager.removeItem(at: finalURL)
            }
            if let wallpaperError = error as? WallpaperLabError { throw wallpaperError }
            if let readFailure = error as? WallpaperPackageReadFailure { throw readFailure }
            throw WallpaperPackageReadFailure(underlyingError: error as NSError)
        }
    }

    private static func coordinatedCopyArchive(from sourceURL: URL, to destinationURL: URL) throws {
        var coordinationError: NSError?
        var accessorError: Error?
        var copied = false
        let coordinator = NSFileCoordinator(filePresenter: nil)
        coordinator.coordinate(readingItemAt: sourceURL, options: [], error: &coordinationError) { accessibleURL in
            do {
                try copyBoundedArchive(from: accessibleURL, to: destinationURL)
                copied = true
            } catch {
                accessorError = error
            }
        }
        if let accessorError { throw accessorError }
        if let coordinationError {
            throw WallpaperPackageReadFailure(underlyingError: coordinationError)
        }
        guard copied else {
            throw WallpaperPackageReadFailure(underlyingError: NSError(
                domain: NSCocoaErrorDomain, code: NSFileReadUnknownError
            ))
        }
    }

    private static func copyBoundedArchive(from sourceURL: URL, to destinationURL: URL) throws {
        // Do not follow symlinks or block on non-file inputs. The coordinated
        // URL is materialized before opening; fstat verifies the opened object.
        let sourceDescriptor = open(sourceURL.path, O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK)
        guard sourceDescriptor >= 0 else {
            if errno == ELOOP { throw WallpaperLabError.symbolicLinkUnsupported }
            throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno))
        }
        defer { close(sourceDescriptor) }
        var sourceInformation = stat()
        guard fstat(sourceDescriptor, &sourceInformation) == 0 else {
            throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno))
        }
        guard sourceInformation.st_mode & mode_t(S_IFMT) == mode_t(S_IFREG) else {
            throw WallpaperLabError.unsupportedPackage
        }
        let destinationDescriptor = open(
            destinationURL.path, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0o600
        )
        guard destinationDescriptor >= 0 else {
            throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno))
        }
        defer { close(destinationDescriptor) }
        let reader = FileHandle(fileDescriptor: sourceDescriptor, closeOnDealloc: false)
        let writer = FileHandle(fileDescriptor: destinationDescriptor, closeOnDealloc: false)
        var copiedBytes: Int64 = 0
        while let chunk = try reader.read(upToCount: 1_024 * 1_024), !chunk.isEmpty {
            copiedBytes += Int64(chunk.count)
            guard copiedBytes <= WallpaperLabLimits.maximumArchiveBytes else {
                throw WallpaperLabError.packageTooLarge
            }
            try writer.write(contentsOf: chunk)
        }
        guard fsync(destinationDescriptor) == 0 else {
            throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno))
        }
    }

    static func validated(
        _ package: WallpaperStagedPackage,
        fileManager: FileManager = .default
    ) throws -> WallpaperStagedPackage {
        let root = try stagingRoot(fileManager: fileManager)
        let directory = package.packageDirectoryURL.standardizedFileURL
        guard directory.deletingLastPathComponent() == root.standardizedFileURL,
              directory.lastPathComponent == package.id.uuidString else {
            throw WallpaperLabError.unsafeArchive
        }
        return try loadPackage(at: directory, fileManager: fileManager)
    }

    static func packages(fileManager: FileManager = .default) -> [WallpaperStagedPackage] {
        guard let root = try? stagingRoot(fileManager: fileManager),
              let directories = try? fileManager.contentsOfDirectory(
                at: root,
                includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey],
                options: [.skipsHiddenFiles]
              ) else { return [] }
        return directories.compactMap { directory in
            guard UUID(uuidString: directory.lastPathComponent) != nil else { return nil }
            return try? loadPackage(at: directory, fileManager: fileManager)
        }.sorted { $0.importedAt > $1.importedAt }
    }

    static func contains(
        repositoryIdentity: String,
        fileManager: FileManager = .default
    ) -> Bool {
        packages(fileManager: fileManager).contains {
            $0.repositoryIdentity == repositoryIdentity
        }
    }

    static func delete(
        _ package: WallpaperStagedPackage,
        fileManager: FileManager = .default
    ) throws {
        let root = try stagingRoot(fileManager: fileManager)
        guard package.packageDirectoryURL.deletingLastPathComponent().standardizedFileURL
                == root.standardizedFileURL,
              package.packageDirectoryURL.lastPathComponent == package.id.uuidString else {
            throw WallpaperLabError.unsafeArchive
        }
        try WallpaperLayoutScanner.validateDirectory(
            package.packageDirectoryURL,
            fileManager: fileManager
        )
        try fileManager.removeItem(at: package.packageDirectoryURL)
    }

    private static func loadPackage(
        at directory: URL,
        fileManager: FileManager
    ) throws -> WallpaperStagedPackage {
        try WallpaperLayoutScanner.validateDirectory(directory, fileManager: fileManager)
        let metadataData = try Data(contentsOf: directory.appendingPathComponent(metadataName))
        let metadata = try PropertyListDecoder().decode(PackageMetadata.self, from: metadataData)
        guard directory.lastPathComponent == metadata.id.uuidString,
              !metadata.displayName.isEmpty,
              metadata.displayName.utf8.count <= 255 else {
            throw WallpaperLabError.unsupportedPackage
        }
        let archiveURL = directory.appendingPathComponent(archiveName)
        let extractedURL = directory.appendingPathComponent(extractedName, isDirectory: true)
        let payload = try TendiesPackageInspector.inspectExtractedPackage(
            at: extractedURL,
            fileManager: fileManager
        )
        let statistics = try WallpaperPackageStatistics.inspect(at: extractedURL, fileManager: fileManager)
        return WallpaperStagedPackage(
            id: metadata.id,
            displayName: metadata.displayName,
            repositoryIdentity: metadata.repositoryIdentity,
            packageDirectoryURL: directory,
            archiveURL: archiveURL,
            extractedURL: extractedURL,
            payload: payload,
            importedAt: metadata.importedAt,
            statistics: statistics
        )
    }

    private static func applicationSupportURL(fileManager: FileManager) throws -> URL {
        guard let url = fileManager.urls(
            for: .applicationSupportDirectory,
            in: .userDomainMask
        ).first else {
            throw WallpaperLabError.accessDenied
        }
        try createApprovedDirectory(url, fileManager: fileManager)
        return url
    }

    private static func createApprovedDirectory(
        _ url: URL,
        fileManager: FileManager
    ) throws {
        if fileManager.fileExists(atPath: url.path) {
            try WallpaperLayoutScanner.validateDirectory(url, fileManager: fileManager)
        } else {
            try fileManager.createDirectory(at: url, withIntermediateDirectories: true)
        }
    }

    private static func isValidMetadataText(
        _ value: String,
        maximumBytes: Int
    ) -> Bool {
        !value.isEmpty
            && value.utf8.count <= maximumBytes
            && !value.unicodeScalars.contains(
                where: CharacterSet.controlCharacters.contains
            )
    }
}

private struct WallpaperPackageReadFailure: LocalizedError {
    let underlyingError: NSError

    var errorDescription: String? {
        let prefix = String(localized: "wallpaper.error.file_read")
        var errors = [underlyingError]
        var cursor = underlyingError
        for _ in 0..<5 {
            guard let nested = cursor.userInfo[NSUnderlyingErrorKey] as? NSError else { break }
            errors.append(nested)
            cursor = nested
        }
        // Recreate system errors without userInfo, which may contain file URLs,
        // paths, or provider account details. Keep domain/code for diagnosis.
        let details = errors.map { error in
            let systemError = NSError(domain: error.domain, code: error.code)
            return "\(systemError.localizedDescription) [\(error.domain):\(error.code)]"
        }
        return ([prefix] + Array(Set(details)).sorted()).joined(separator: "\n")
    }
}

private struct PackageMetadata: Codable {
    let id: UUID
    let displayName: String
    let repositoryIdentity: String?
    let importedAt: Date
}
