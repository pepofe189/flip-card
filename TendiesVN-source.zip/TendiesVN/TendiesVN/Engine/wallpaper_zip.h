// SPDX-License-Identifier: GPL-3.0-only
// Adapted from 3105 (https://github.com/YangJiiii/3105), YangJiii and contributors.
// Integrated into the TendiesVN wallpaper-only engine on 2026-10-16.
// Extraction algorithm preserved; project attribution and license notice added.
// See LICENSE and THIRD_PARTY_NOTICES.md in the project root.

#ifndef WALLPAPER_ZIP_H
#define WALLPAPER_ZIP_H

#include <stdint.h>

int wallpaper_zip_extract_entry(
    const char *archive_path,
    uint64_t data_offset,
    uint64_t compressed_size,
    uint16_t compression_method,
    const char *destination_path,
    uint64_t expected_size,
    uint32_t expected_crc32
);

#endif
