import Foundation
import UniformTypeIdentifiers

enum PairingFileType {
    static let mobileDevicePairing = UTType(
        importedAs: "app.1809.mobiledevicepairing", conformingTo: .data
    )
    private static let extensions = ["mobiledevicepairing", "mobilepair", "plist"]

    static func supports(_ url: URL) -> Bool {
        url.isFileURL && extensions.contains(url.pathExtension.lowercased())
    }

    static var pickerContentTypes: [UTType] {
        // A provider may use another app's UTI, a dynamic UTI, or public.data
        // for the same filename. Include every registration and broad types so
        // those files stay selectable; PairingStore validates the actual data.
        let registrations = extensions.flatMap {
            UTType.types(tag: $0, tagClass: .filenameExtension, conformingTo: nil)
        }
        let fallbacks: [UTType] = [
            mobileDevicePairing, .propertyList, .xml, .data, .content, .item
        ]
        var seen = Set<String>()
        return (registrations + fallbacks).filter { seen.insert($0.identifier).inserted }
    }
}
