#!/usr/bin/env python3
"""Verify a built app and ensure its signature matches its actual Bundle ID."""

import argparse
from pathlib import Path
import plistlib
import subprocess
import sys

from signing_common import bundle_identifier, profile_metadata
MACHO_MAGICS = {
    b"\xcf\xfa\xed\xfe", b"\xfe\xed\xfa\xcf",  # Mach-O 64-bit
    b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca",  # universal
    b"\xca\xfe\xba\xbf", b"\xbf\xba\xfe\xca",  # universal 64-bit
}


def verify_app(app: Path, require_signature: bool, expected_bundle_id: str = None) -> None:
    with (app / "Info.plist").open("rb") as handle:
        info = plistlib.load(handle)
    actual_bundle_id = bundle_identifier(info.get("CFBundleIdentifier"))
    if expected_bundle_id is not None and actual_bundle_id != bundle_identifier(expected_bundle_id):
        raise ValueError(f"CFBundleIdentifier is {actual_bundle_id}; expected {expected_bundle_id}.")
    name = info.get("CFBundleExecutable")
    if not isinstance(name, str) or not name or Path(name).name != name:
        raise ValueError("CFBundleExecutable is invalid.")
    executable = app / name
    with executable.open("rb") as handle:
        if handle.read(4) not in MACHO_MAGICS:
            raise ValueError("App executable is not a built 64-bit Mach-O binary.")
    if not executable.stat().st_mode & 0o111:
        raise ValueError("App binary is not executable.")
    if require_signature:
        subprocess.run(["codesign", "--verify", "--deep", "--strict", str(app)], check=True)
        description = subprocess.run(
            ["codesign", "--display", "--verbose=4", str(app)],
            check=True, capture_output=True, text=True,
        )
        lines = (description.stdout + "\n" + description.stderr).splitlines()
        if f"Identifier={actual_bundle_id}" not in lines:
            raise ValueError(f"CodeDirectory identifier must match the app's Bundle ID ({actual_bundle_id}).")
        if "Signature=adhoc" in lines:
            raise ValueError("An ad hoc signature cannot be used for enterprise installation.")
        profile = app / "embedded.mobileprovision"
        decoded = subprocess.run(
            ["security", "cms", "-D", "-i", str(profile)],
            check=True, capture_output=True,
        )
        provisioning = plistlib.loads(decoded.stdout)
        team, _ = profile_metadata(provisioning, actual_bundle_id)
        if f"TeamIdentifier={team}" not in lines:
            raise ValueError("CodeDirectory team does not match the embedded provisioning profile.")
        signature_entitlements = subprocess.run(
            ["codesign", "--display", "--entitlements", ":-", str(app)],
            check=True, capture_output=True,
        )
        signed = plistlib.loads(signature_entitlements.stdout)
        if signed.get("com.apple.developer.team-identifier") != team:
            raise ValueError("Signed app team does not match the embedded provisioning profile.")
        app_id = signed.get("application-identifier")
        prefixes = provisioning["ApplicationIdentifierPrefix"]
        profile_app_id = provisioning["Entitlements"]["application-identifier"]
        if app_id not in [prefix + "." + actual_bundle_id for prefix in prefixes
                          if isinstance(prefix, str) and profile_app_id.startswith(prefix + ".")]:
            raise ValueError("Signed application identifier does not match the app's Bundle ID and profile prefix.")
        if signed.get("get-task-allow", False):
            raise ValueError("Signed app permits debugging rather than enterprise distribution.")
    print(f"Verified {app.name}: {actual_bundle_id}" + ("; enterprise signature present" if require_signature else ""))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("app", type=Path)
    parser.add_argument("--require-signature", action="store_true")
    parser.add_argument("--bundle-id", help="Optional expected Bundle ID; otherwise verify the app's actual identifier")
    args = parser.parse_args()
    try:
        verify_app(args.app, args.require_signature, args.bundle_id)
    except (OSError, ValueError, plistlib.InvalidFileException, subprocess.CalledProcessError) as exc:
        print(f"Verification failed: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
