#!/usr/bin/env python3
"""Print actionable compiler errors near the end of a failed Actions log."""

import argparse
from pathlib import Path
import re
import sys


ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
ERROR = re.compile(r"(?:^|\s)(?:fatal )?error:|^Undefined symbols for architecture|^ld: (?!warning:)", re.I)


def summarize(log: str, maximum_errors: int = 8) -> str:
    lines = ANSI.sub("", log).splitlines()
    selected = []
    seen = set()
    for index, line in enumerate(lines):
        if ERROR.search(line) and line.strip() not in seen:
            selected.append(index)
            seen.add(line.strip())
            if len(selected) == maximum_errors:
                break
    if not selected:
        tail = "\n".join(lines[-16:])
        return "No compiler error line was found. Last build output:\n" + tail

    output = ["First compiler errors (full output: build/xcodebuild.log):"]
    last_printed = -1
    for index in selected:
        for cursor in range(max(last_printed + 1, index - 1), min(len(lines), index + 3)):
            # Keep diagnostics intact; bound neighboring command-line noise.
            line = lines[cursor]
            output.append(line if ERROR.search(line) else line[:500])
            last_printed = cursor
    return "\n".join(output)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("log", type=Path)
    args = parser.parse_args()
    try:
        log = args.log.read_text(encoding="utf-8", errors="replace")
    except OSError as error:
        print(f"Could not read build log: {error}", file=sys.stderr)
        return 1
    print(summarize(log))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
