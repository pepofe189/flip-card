#!/usr/bin/env python3
"""Fetch the pinned, checksum-verified standard pairing library for Xcode.

Only the selected platform slice is extracted. The library stays in build/ and
is linked statically; no framework is downloaded at app runtime.
"""
import argparse
import hashlib
from pathlib import Path
import shutil
import tempfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VERSION = "0.1.68"
URL = f"https://github.com/jkcoxson/idevice/releases/download/v{VERSION}/idevice-xcframework-v{VERSION}.zip"
SHA256 = "c9eccdd1942de756d746a2569d93302774ab0eff1cff314ec8118f768b3d8dc7"
HEADER_SHA256 = "696286794e8cf1c18a91d4dab5046cef4d9bae352f5e7a1ad33fbc0ba30d7ab4"
SLICES = {
    "iphoneos": ("ios-arm64", "libidevice_ffi.a"),
    "iphonesimulator": ("ios-arm64_x86_64-simulator", "idevice-ios-sim.a"),
    "macosx": ("macos-arm64_x86_64", "idevice-macos.a"),
}


def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            result.update(chunk)
    return result.hexdigest()


def prepare(platform, supplied_archive=None):
    base = ROOT / "build/Dependencies/IDevice"
    base.mkdir(parents=True, exist_ok=True)
    archive = Path(supplied_archive) if supplied_archive else base / f"idevice-{VERSION}.zip"
    if supplied_archive and (not archive.is_file() or digest(archive) != SHA256):
        raise ValueError("Provided idevice archive failed the pinned SHA256 check")
    if not archive.is_file() or digest(archive) != SHA256:
        print(f"Downloading idevice {VERSION} (~204 MB)…", flush=True)
        with tempfile.NamedTemporaryFile(dir=base, suffix=".download", delete=False) as handle:
            temporary = Path(handle.name)
        try:
            with urllib.request.urlopen(URL, timeout=60) as response, temporary.open("wb") as output:
                shutil.copyfileobj(response, output)
            if digest(temporary) != SHA256:
                raise ValueError("Downloaded idevice archive failed the pinned SHA256 check")
            temporary.replace(archive)
        finally:
            temporary.unlink(missing_ok=True)
    slice_name, library = SLICES[platform]
    prefix = f"swift/IDevice.xcframework/{slice_name}/"
    destination = base / platform
    destination.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive) as package:
        header = package.read(prefix + "Headers/idevice.h")
        if hashlib.sha256(header).hexdigest() != HEADER_SHA256:
            raise ValueError("idevice header does not match the pinned app bindings")
        expected_header = ROOT / "TendiesVN/Engine/IDevice/idevice.h"
        if expected_header.read_bytes() != header:
            raise ValueError("App pairing bindings differ from the pinned release")
        with tempfile.NamedTemporaryFile(dir=destination, delete=False) as output:
            temporary = Path(output.name)
            try:
                with package.open(prefix + library) as source:
                    shutil.copyfileobj(source, output)
                output.flush()
            except BaseException:
                temporary.unlink(missing_ok=True)
                raise
        temporary.replace(destination / "libidevice_ffi.a")
    print(f"Verified idevice {VERSION}: {platform}", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--platform", choices=SLICES, default="iphoneos")
    parser.add_argument("--archive", type=Path, help="Use an already downloaded pinned archive")
    options = parser.parse_args()
    prepare(options.platform, options.archive)
