#!/usr/bin/env python3
"""Portable regression checks for configurable signing identifiers; no Apple keys."""

from datetime import datetime, timedelta, timezone
import hashlib
import importlib.util
from pathlib import Path
import plistlib
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from signing_common import DEFAULT_BUNDLE_ID, profile_metadata

SCRIPTS = Path(__file__).resolve().parent


def load_script(name, filename):
    spec = importlib.util.spec_from_file_location(name, SCRIPTS / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


prepare_signing = load_script("prepare_signing", "prepare-signing.py")
verify_app = load_script("verify_app", "verify-app.py")


class SigningTests(unittest.TestCase):
    def setUp(self):
        self.bundle_id = "com.example.custom-wallpaper"
        self.certificate = b"public certificate fixture for metadata tests only"
        self.fingerprint = hashlib.sha1(self.certificate).hexdigest().upper()
        self.profile = {
            "ProvisionsAllDevices": True,
            "ExpirationDate": datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(days=1),
            "TeamIdentifier": ["ABCD123456"],
            "ApplicationIdentifierPrefix": ["ABCD123456"],
            "UUID": "00000000-1111-2222-3333-444444444444",
            "Entitlements": {"application-identifier": "ABCD123456." + self.bundle_id,
                             "com.apple.developer.team-identifier": "ABCD123456"},
            "DeveloperCertificates": [self.certificate],
        }

    def test_custom_and_wildcard_profiles(self):
        self.assertEqual(profile_metadata(self.profile, self.bundle_id)[0], "ABCD123456")
        self.profile["Entitlements"]["application-identifier"] = "ABCD123456.com.example.*"
        profile_metadata(self.profile, self.bundle_id)
        with self.assertRaisesRegex(ValueError, "does not permit"):
            profile_metadata(self.profile, DEFAULT_BUNDLE_ID)

    def test_expired_or_wrong_team_profile_rejected(self):
        self.profile["ExpirationDate"] = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=1)
        with self.assertRaisesRegex(ValueError, "expired"):
            profile_metadata(self.profile, self.bundle_id)
        self.profile["ExpirationDate"] = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(days=1)
        self.profile["Entitlements"]["com.apple.developer.team-identifier"] = "OTHER12345"
        with self.assertRaisesRegex(ValueError, "team"):
            profile_metadata(self.profile, self.bundle_id)

    def test_export_options_use_chosen_id_and_matching_certificate(self):
        def run(args, **kwargs):
            if args[1] == "cms":
                return subprocess.CompletedProcess(args, 0, plistlib.dumps(self.profile), b"")
            return subprocess.CompletedProcess(args, 0, f'  1) {self.fingerprint} "Apple Distribution: Test"\n', "")

        with tempfile.TemporaryDirectory() as temporary, patch.object(prepare_signing.subprocess, "run", side_effect=run):
            options_path = Path(temporary) / "options.plist"
            prepare_signing.prepare(Path("fixture.mobileprovision"), self.fingerprint, options_path, self.bundle_id)
            options = plistlib.loads(options_path.read_bytes())
            self.assertEqual(options["provisioningProfiles"], {self.bundle_id: self.profile["UUID"]})
            self.profile["DeveloperCertificates"] = [b"other certificate"]
            with self.assertRaisesRegex(ValueError, "not included"):
                prepare_signing.prepare(Path("fixture.mobileprovision"), self.fingerprint, options_path, self.bundle_id)

    def test_generic_verifier_accepts_changed_id_but_checks_expectation(self):
        with tempfile.TemporaryDirectory() as temporary:
            app = Path(temporary) / "Fixture.app"
            app.mkdir()
            (app / "Info.plist").write_bytes(plistlib.dumps({"CFBundleIdentifier": self.bundle_id,
                                                          "CFBundleExecutable": "Fixture"}))
            # Only a verifier input fixture; never packaged or presented as an app.
            executable = app / "Fixture"
            executable.write_bytes(b"\xcf\xfa\xed\xfe" + bytes(64))
            executable.chmod(0o755)
            verify_app.verify_app(app, False)
            with self.assertRaisesRegex(ValueError, "expected"):
                verify_app.verify_app(app, False, DEFAULT_BUNDLE_ID)
            with patch.object(verify_app.subprocess, "run", side_effect=[
                subprocess.CompletedProcess([], 0),
                subprocess.CompletedProcess([], 0, "", "Identifier=com.example.wrong\n"),
            ]):
                with self.assertRaisesRegex(ValueError, "CodeDirectory"):
                    verify_app.verify_app(app, True)
            with patch.object(verify_app.subprocess, "run", side_effect=[
                subprocess.CompletedProcess([], 0),
                subprocess.CompletedProcess([], 0, "", f"Identifier={self.bundle_id}\nTeamIdentifier=ABCD123456\n"),
                subprocess.CompletedProcess([], 0, plistlib.dumps(self.profile), b""),
                subprocess.CompletedProcess([], 0, plistlib.dumps(self.profile["Entitlements"]), b""),
            ]):
                verify_app.verify_app(app, True)

    def test_manifest_cli_matches_custom_id_and_build(self):
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "manifest.plist"
            subprocess.run([sys.executable, str(SCRIPTS / "make-ota-manifest.py"),
                            "--ipa-url", "https://example.com/1809.ipa", "--output", str(output),
                            "--bundle-id", self.bundle_id], check=True, capture_output=True)
            metadata = plistlib.loads(output.read_bytes())["items"][0]["metadata"]
            self.assertEqual(metadata["bundle-identifier"], self.bundle_id)
            self.assertEqual(metadata["bundle-version"], "19")


if __name__ == "__main__":
    unittest.main()
